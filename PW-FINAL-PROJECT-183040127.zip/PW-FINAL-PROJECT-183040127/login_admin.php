<?php 
session_start();
require "functions.php";

// cek cookie
if(isset($_COOKIE['cookie1']) && isset($_COOKIE['cookie2'])) {
    $cookie1    = $_COOKIE['cookie1'];
    $cookie2   = $_COOKIE['cookie2'];

    // mengambil username berdasarkan id
    $cek_user = mysqli_query($conn, "SELECT username FROM daftar_film WHERE cookie1 = $cookie1");
    $row = mysqli_fetch_assoc($cek_user);

    // cek cookie & username 
    if($cookie2 == hash('sha256', $row['username'])) {
        $_SESSION['user'] = true;
    }
}


if (isset($_SESSION['user'])) {
	header("Location: halaman_admin.php");
	exit;
}


if (isset($_POST['login'])) {
	$username = $_POST['user'];
	$password = $_POST['pass'];
	$cek_user = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");
	if (mysqli_num_rows($cek_user) == 1) {
		$row = mysqli_fetch_assoc($cek_user);
		if (password_verify($password, $row['password'])) {

			// sukses login
			$_SESSION['user'] = true;
			// $_SESSION['user'] = $_POST['user'];
			// $_SESSION['hash'] = hash('sha256', $row['id'], false);
			// if (hash('sha256',$row['id']) == $_SESSION['hash']) {
			// 	header("Location: halaman_admin.php");
			// 	die;
			// }
			// remember check
                if (isset($_POST['remember'])) {
                    // made cookie
                    setcookie('cookie1', $row['id'], time()+60);
                    setcookie('cookie2', hash('sha256', $row['username']), time()+60);
                }
			header("Location: halaman_admin.php");
			exit;
		} else {
            // failed login
            $error = 'username / password salah!';
            }
        } else {
            // failed login
            $error = 'username belum registrasi!';
        }
}
// if (isset($_POST['login'])) {
// 	if ($_POST['user'] == 'admin' && $_POST['pass'] == 'admin') {
// 		header("Location: halaman_admin.php");
// 		exit;

// 	} else {
// 		$nValid = true;
// 	}
// }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Login</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<style type="text/css">
	body {
		font-family: arial;
		font-size: 14px;
		background-color: #222;
	}

	#utama {
		width: 300px;
		margin: 0 auto;
		margin-top: 12%;
	}

	#judul {
		padding: 15px;
		text-align: center;
		color: #fff;
		font-size: 20px;
		background-color: #339966;
		border-top-right-radius: 10px;
		border-top-left-radius: 10px; 
		border-bottom: 3px solid #336666;
	}

	#inputan {
		background-color: #eaeaec;
		padding: 20px;
		border-bottom-right-radius: 10px;
		border-bottom-left-radius: 10px; 
	}

	input {
		padding: 10px;
		border: 0;
	}

	.lg {
		width: 240px;
	}

	.btn {
		background-color: #339966;
		border-radius: 10px;
		color: #fff;
		height: 50px;
		width: 60px;
	}

	.btn:hover {
		background-color: #336666;
		cursor: pointer;
	}
</style>
</head>
<body>
	<div id="utama">
		<div id="judul">
			Halaman Login
		</div>
		<div id="inputan">
			<form action="" method="post">
				<div>
					<input type="text" name="user" placeholder="Username" class="lg">
				</div>
				<div style="margin-top: 10px;">
					<input type="password" name="pass" placeholder="Password" class="lg">
				</div><br>
				<?php if( isset($error) ) : ?>
					<p style="color: red; font-style: italic;"><i><?= $error; ?></i></p>
				<?php endif; ?>
				<input type="checkbox" name="remember" id="remember">
				<label for="remember">Remember Me</label>
				<br><a href="registrasi.php">Registrasi</a><br>
				<div style="margin-top: 10px;">
					<input type="submit" name="login" value="login" class="btn">
				</div>
			</form>
		</div>
	</div>

	
</body>
</html>
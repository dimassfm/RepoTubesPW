<?php
session_start();
if (!isset($_SESSION['user'])) {
	header("Location: login_admin.php");
	exit;
}
//Connet To Databases
require 'functions.php';
$genre = query("SELECT * FROM Genre ");
//Tombol Submit mengecek sudah di tekan atau belum
if( isset($_POST["tambah"]) ) {
//Pengecekan Berhasil Apa gagal
	if( tambah($_POST) > 0 ) {
		echo "
			<script>
				alert('Data Berhasil Ditambahkan!');
				document.Location.href = 'halaman_admin.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('Data Gagal Ditambahkan!');
				document.Location.href = 'halaman_admin.php';
			</script>
		";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Tambah Data Daftar Film</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<h2 class="text-center mb-5">Tambah Data Daftar Film </h2>
			
	<div class="kotak_tambah">
    	<h4 class="tulisan text-center">Silakan Masukkan Data Baru</h4><br>
    			
    		<form method="post" action="" enctype="multipart/form-data">

    		<div class="form-group">
				<label for="Masukkan Judul Film">Masukkan Judul Film : </label> 
				<input type="text" name="Judul" class="form-control form-control-sm" required>
			</div>
				
			<div class="form-group">
				<select class="form-control form-control-m selectpicker" data-style="btn-white" data-live-search="true" data-size="5" name="Genre" required>
					<option value="">Masukkan Genre...</option>
					<?php foreach ($genre as $g) { ?>
					<option value="<?= $g['Id'] ?>"><?= $g['Genre'] ?></option>					
					<?php  } ?>
				</select>
			</div>

			<div class="form-group">
				<label for="Masukkan Sutradara">Masukkan Sutradara Film:</label>	 
				<input type="text" name="Sutradara" class="form-control form-control-sm" required>
			</div>

			<div class="form-group">
				<label for="Masukkan Produser">Masukkan Produser :</label>	 	 					
				<input type="text" name="Produser" class="form-control form-control-sm" required>
			</div>

				<div class="form-group">
				<label for="Masukkan Produser">Masukkan Produser :</label>
				<input type="text" name="Produser" class="form-control form-control-sm" required>	 
				</div>

				<div class="form-group">
				<label for="Masukkan Sinopsis">Masukkan Sinopsis :</label>
				<textarea name="Sinopsis" rows="10" class="form-control form-control-sm" required></textarea>	 
				</div>	 
				
				<div>
					<label for="Masukkan Gambar">Masukkan Gambar :</label>		 
					<input type="file" name="Gambar" required>
				</div>
				<br>
				<br>
					<button type="submit" name="tambah" class="btn btn-primary">Tambah Data Film</button>
					<button type="button" onclick="window.location.href = 'halaman_admin.php';" class="btn btn-primary">Kembali</button>
			</form>
		</div>
	
	
	
</body>
</html>
<?php 

session_start();
session_destroy();
setcookie('cookie1', '', time()-3600);
setcookie('cookie2', '', time()-3600);
header("Location: index.php");
exit;
 ?>
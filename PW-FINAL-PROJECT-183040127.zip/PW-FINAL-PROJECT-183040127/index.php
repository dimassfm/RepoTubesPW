<?php
require 'functions.php';
 $film = query("SELECT * FROM daftar_film");


if( isset($_POST["cari"]) ) {
	$film = cari($_POST["keyword"]);
}

if (isset($_POST['login'])) {
	if ($_POST['user'] == 'admin' && $_POST['pass'] == 'admin') {
		header("Location: halaman_admin.php");
		exit;
	} else {
		$nValid = true;
	}
}
?>
<!DOCTYPE html>
<html lang="en" id="home">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<head>
	<title>WEB DIMAS</title>
	<!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<style type="text/css">
	
</style>
</head>
<body>

<!-- navbar -->
	
  <nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="#">WEB DIMAS</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#"><span><i class="fas fa-home"></i></span> HOME<span class="sr-only">(current)</span></a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" id="keyword" autocomplete="off">
      <button class="btn btn-success my-2 my-sm-0 mr-4" type="submit" id="cari"><span class="fas fa-search"></span>Search</button>
    </form>
    <div class="btn btn-light justify-content mr-7" >
    <a href="login_admin.php"><i class="fas fa-sign-in-alt"></i> LOGIN</a>
  	</div>
  </div>
</nav>


		<!-- akhir navbar -->

	<div id="isi">
		<h2 class="text-center mb-5">Daftar Film Terpuler di Indonesia</h2>

	<?php if(empty($film) ) : ?>
			<tr>
				<center><td colspan="6">Data tidak ditemukan!</td></center>
			</tr>
		<?php endif; ?>

 <div id="container"><div class="w-75 m-auto card-columns">
			<?php foreach ($film as $flm) : ?>
        <div class="content card text-center">
           	<div class="gambar">
                   <p><img class="card-img-top" src="assets/img/<?= $flm["Gambar"]; ?>"></p>
           	</div>
           	<div class="card-body">
            <p class="nama card-text">
				<a href="profil.php?id=<?= $flm["Id"]; ?>"><?= $flm["Judul"]; ?></a>
			</p>
			<p><?= $flm["Sutradara"]; ?></p>
			<a href="profil.php?id=<?= $flm["Id"]; ?>"><button class="btn w-50 btn-primary">Read More</button></a>
			</div>
        </div>
        <?php endforeach; ?>
        </div>
 </div>
</div>

 <!-- footer -->
    <footer class="bg-primary text-white">
      <div class="row pt-3">
        <div class="col text-center">
          <p>Coyright 2018 | built with by. Dimas Faturohman</p>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 text-center">
            <a href="http://instagram.com/dimasfm33" class="btn btn-danger">Follow My Instagram</a>
        </div>
      </div>
     <br>
    </footer>
    <!-- akhir footer -->


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    <script src="js/script.js"></script>
    <script src="ajax/ajaxuser.js"></script>
</body>
</html>
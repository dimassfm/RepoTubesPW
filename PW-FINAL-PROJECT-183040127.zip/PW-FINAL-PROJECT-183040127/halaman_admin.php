 <?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login_admin.php");
  exit;
}
//Connect To Databases => funtions
require 'functions.php';
//Query data Tabel Film
$film = query("SELECT * FROM daftar_film,genre WHERE genre.Id = daftar_film.Genre");


if( isset($_POST["cari"]) ) {
  $film = cari($_POST["keyword"]);
}
 
?>
<!DOCTYPE html>
<html>
<head>
  <style>
    @media print {
      .aksi_aksi, .footer_footer {
        display: none;
      }
    }
  </style>

  <title>ADMINISTRATOR</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
</head>
<!-- Bootstrap -->
    
<body id="body">
  <style>
    #body {
  background: #02fdff;
  }
  #tabel {
    background: #bebfbf;
  }
  </style>
<nav class="navbar sticky-top navbar-expand-lg navbar navbar-dark bg-primary">
  <a class="navbar-brand" href="#"><img src="">ADMINISTRATOR</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#"><span><i class="fas fa-home"></i></span> Home<span class="sr-only">(current)</span></a>
      </li>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" id="keyword" autocomplete="off">
      <button class="btn btn-success my-2 my-sm-0" type="submit" id="cari"><span class="fas fa-search"></span>Search</button>
    </form>
  </div>

  <a type="button" class="btn btn-success mr-4" href="tambah.php"><span><i class="fas fa-plus-square"></i></span> Tambahkan Film<a/>
  <a type="button" class="btn btn-danger mr-4" href="logout.php"><span><i class="fas fa-sign-out-alt"></i></span> Logout</a>
</nav>
<br>
  <div id="box">
    <table id="tabel" align="center" border="1"  cellspacing="0" cellpadding="10">
      <tr>
        <th style="text-align: center;">No.</th>
        <th style="text-align: center;">Gambar</th>
        <th style="text-align: center;">Judul Film</th>
        <th style="text-align: center;">Sutradara</th>
        <th style="text-align: center;">Genre</th>
        <th style="text-align: center;">Produser</th>
        <th style="text-align: center;">Sinopsis</th>
        <th style="text-align: center;" class="aksi_aksi">Aksi</th>
      </tr>
      <?php $i = 1; ?>  
        <?php foreach($film as $flm) : ?>
      <tr>  
        <td><?= $i++; ?></td>
        <td><img  width="150px;" src="assets/img/<?= $flm["Gambar"]; ?>"></td>
        <td width="150px;" class="text-center"><?= $flm["Judul"]; ?></td>
        <td width="150px;" class="text-center"><?= $flm["Sutradara"]; ?></td>
        <td width="150px;" class="text-center"><?= $flm["Genre"]; ?></td>
        <td width="150px;" class="text-center"><?= $flm["Produser"]; ?></td>
        <td width="300px;" class="text-center"><?= $flm["Sinopsis"]; ?></td>
        <td class="aksi_aksi">
          <a type="button" class="sign-out-alt btn btn-primary" href="ubah.php?id=<?= $flm["Id"]; ?> "><span class="fas fa-pencil-alt"></span> Ubah</a> | 
          <a type="button" class="btn btn-danger" a href="hapus.php?id=<?= $flm["Id"]; ?>" onclick="return confirm('Yakin akan dihapus?')"><span class="fas fa-trash"></span> Hapus</a>
        </td>
      </tr>
        <?php endforeach; ?>
    </table>
  </div>
  <br>
  
<!-- footer -->
  <div class="footer_footer">
    <footer class="bg-primary text-white">
      <div class="row pt-3">
        <div class="col text-center">
          <p>Coyright 2018 | built with by. Dimas Faturohman</p>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 text-center">
            <a href="http://instagram.com/dimasfm33" class="btn btn-danger">Follow My Instagram</a>
        </div>
      </div>
     <br>
    </footer>
    </div>
    <!-- akhir footer -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    <script src="js/script.js"></script>
    <script src="ajax/ajaxadmin.js"></script>
</body>
</html>
<?php
require '../functions.php';

$keyword = $_GET["keyword"];
$query_search = "SELECT * FROM daftar_film
				JOIN genre
				ON genre.Id = daftar_film.Genre
				WHERE
				Judul LIKE '%$keyword%' OR
				genre.Genre LIKE '%$keyword%' OR
				Sutradara LIKE '%$keyword%' OR
				Sinopsis LIKE '%$keyword%' OR
				Produser LIKE '%$keyword%'";
$film = query($query_search);

?>

<div id="container"><div class="w-75 m-auto card-columns">
			<?php foreach ($film as $flm) : ?>
        <div class="content card text-center">
           	<div class="gambar">
                   <p><img class="card-img-top" src="assets/img/<?= $flm["Gambar"]; ?>"></p>
           	</div>
           	<div class="card-body">
            <p class="nama card-text">
				<a href="profil.php?id=<?= $flm["Id"]; ?>"><?= $flm["Judul"]; ?></a>
			</p>
			<p><?= $flm["Sutradara"]; ?></p>
			<a href="profil.php?id=<?= $flm["Id"]; ?>"><button class="btn w-50 btn-primary">Read More</button></a>
			</div>
        </div>
        <?php endforeach; ?>
        </div>
 </div>
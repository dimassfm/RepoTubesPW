<?php
require '../functions.php';

$keyword = $_GET["keyword"];
$query_search = "SELECT * FROM daftar_film
				JOIN genre
				ON genre.Id = daftar_film.Genre
				WHERE
				Judul LIKE '%$keyword%' OR
				genre.Genre LIKE '%$keyword%' OR
				Sutradara LIKE '%$keyword%' OR
				Sinopsis LIKE '%$keyword%' OR
				Produser LIKE '%$keyword%'";
$film = query($query_search);

?>

 <table id="tabel" align="center" border="1"  cellspacing="0" cellpadding="10">
      <tr>
        <th style="text-align: center;">No.</th>
        <th style="text-align: center;">Gambar</th>
        <th style="text-align: center;">Judul Film</th>
        <th style="text-align: center;">Sutradara</th>
        <th style="text-align: center;">Genre</th>
        <th style="text-align: center;">Produser</th>
        <th style="text-align: center;">Aksi</th>
      </tr>
      	<?php if (empty($film)) : ?>
      	<tr>
      		<td colspan="8" class="text-center">
      			Data tidak ditemukan
      		</td>
      	</tr>
  		<?php endif; ?>
      <?php $i = 1; ?>  
        <?php foreach($film as $flm) : ?>
      <tr>
        <td><?= $i++; ?></td>
        <td><img  width="150px;" src="assets/img/<?= $flm["Gambar"]; ?>"></td>
        <td width="150px;" class="text-center"><?= $flm["Judul"]; ?></td>
        <td width="150px;" class="text-center"><?= $flm["Sutradara"]; ?></td>
        <td width="150px;" class="text-center"><?= $flm["Genre"]; ?></td>
        <td width="150px;" class="text-center"><?= $flm["Produser"]; ?></td>
        <td width="300px;" class="text-center"><?= $flm["Sinopsis"]; ?></td>
        <td>
          <a type="button" class="sign-out-alt btn btn-primary" href="ubah.php?id=<?= $flm["Id"]; ?> "><span class="fas fa-pencil-alt"></span> Ubah</a> | 
          <a type="button" class="btn btn-danger" a href="hapus.php?id=<?= $flm["Id"]; ?>" onclick="return confirm('Yakin akan dihapus?')"><span class="fas fa-trash"></span> Hapus</a>
        </td>
      </tr>
        <?php endforeach; ?>
    </table>
<?php
if(!isset($_GET['id'])) {
	header("Location: index.php");
	exit;
}

require 'functions.php';
$id = $_GET['id'];

$flm = query("SELECT * FROM daftar_film,genre WHERE genre.Id = daftar_film.Genre AND daftar_film.id = $id")[0];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Profil</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<style> 

</style>
<body>
<h1  class="text-center mb-5">Detail Film</h1>
	<div class="card mb-3 mx-auto text-light bg-primary" style="max-width: 700px; text-align: center;">
   <div class="content row no-gutters">
   	 <div class="col-md-4">
           <div class="gambar">
                <img class="card-img-top" src="assets/img/<?= $flm["Gambar"]; ?>">
           			</div>
          		</div>
          	<div class="col-md-8">
      		<div class="card-body">
			<div class="desc">
            	<p class="nama card-text">Judul: <?= $flm["Judul"]; ?></p>
				<p class="nama card-text">Sutradara: <?= $flm["Sutradara"]; ?></p>
				<p class="nama card-text">Genre: <?= $flm["Genre"]; ?></p>
				<p class="nama card-text">Produser: <?= $flm["Produser"]; ?></p>
				<p class="nama card-text">Sinopsis: <?= $flm["Sinopsis"]; ?></p>
				</div>
				</div>
			</div>
		</div>
   </div>
</body>
</html>
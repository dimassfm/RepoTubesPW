<?php

	$conn = mysqli_connect('localhost', 'root', '', 'pw_kamis07_183040127');


function query($query) {
	global $conn;
	
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	};
	return $rows;
}	


function cari($keyword) {
	$query = "SELECT * FROM daftar_film,genre WHERE genre.Id = daftar_film.Genre AND
				(Judul LIKE '%$keyword%' OR
				Sutradara LIKE '%$keyword%' OR
				genre.Genre LIKE '%$keyword%' OR
				Produser LIKE '%$keyword%' OR
				Sinopsis LIKE '%$keyword%')
			";
	return query($query);

	}

function hapus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM daftar_film WHERE Id = $id");

	return mysqli_affected_rows($conn);

		
	}

function tambah($data) {
	global $conn;
	
	$film = htmlspecialchars($data["Judul"]);
	$genre = htmlspecialchars($data["Genre"]);
	$sutradara = htmlspecialchars($data["Sutradara"]);
	$produser = htmlspecialchars($data["Produser"]);
	$sinopsis = htmlspecialchars($data["Sinopsis"]);
	

	// Upload Gambar
	$gambar = upload();
	if (!$gambar) {
		return false;
	}
	
	// Query insert data 
	$query = "INSERT INTO daftar_film VALUES 
				('', '$film', '$genre', '$sutradara', '$produser', '$gambar', '$sinopsis')
			 ";
	mysqli_query($conn, $query);
	
	return mysqli_affected_rows($conn);
}


function ubah($data) {
	global $conn;

	$id = $data['Id'];
	$judul = htmlspecialchars($data['Judul']);
	$genre = htmlspecialchars($data['Genre']);
	$sutradara = htmlspecialchars($data['Sutradara']);
	$produser = htmlspecialchars($data['Produser']);
	$sinopsis = htmlspecialchars($data['Sinopsis']);
	$gambarlama = htmlspecialchars($data['GambarLama']);

	// Pengecekan User Gambar baru atau tidak 
	if( $_FILES['Gambar']['error'] === 4 ) {
		$gambar= $gambarlama;
	} else {
		$gambar = upload();
	}

	$query = "UPDATE daftar_film SET
				Judul = '$judul',
				Genre = '$genre',
				Sutradara = '$sutradara',
				Produser = '$produser',
				Sinopsis = '$sinopsis',
				Gambar = '$gambar'
			  WHERE Id = $id
				";

	mysqli_query($conn, $query);
	
	return mysqli_affected_rows($conn);

	}


function upload() {
	$file = $_FILES['Gambar']['name'];
	$ukuranFile = $_FILES['Gambar']['size'];
	$error = $_FILES['Gambar']['error'];
	$tmpname = $_FILES['Gambar']['tmp_name'];
	
	// Pengecekan Upload File Dari User
	if ($error === 4 ) {
		print "<script>
				alert('Pilih gambar terlebih dahulu!');
			   </script>";
		return false;
	}
	
	// Pengecekan Apakah type nya gambar
	$ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
	$ekstensiGambar = explode('.', $file);
	$ekstensiGambar = strtolower(end($ekstensiGambar));
	if( !in_array($ekstensiGambar, $ekstensiGambarValid)) {
		print "<script>
				alert('Yang anda upload bukan Gambar!');
			   </script>";
		return false;
	}
	
	// Pengecekan ukuran Gambar 
	if( $ukuranFile > 1000000) {
		print "<script>
				alert('Ukuran File Gambar Terlalu Besar!');
			   </script>";
		return false;
	}
	
	

	//Generate nama gambar baru
	$FileBaru = uniqid();
	$FileBaru .= '.';
	$FileBaru .= $ekstensiGambar;
	
	
	// Sukses dan Lolos Mengupload dalam 3 Pengecekan
	move_uploaded_file($tmpname, 'assets/img/' . $FileBaru);
	
	return $FileBaru;
}


function registrasi($data) {
	global $conn;
	
	$username = $data['username'];
	$password = $data['password'];
	$password2 =$data['password2'];
	
	
	// Pengecekan username yang sudah ada atau belum
	$result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");
	
	if (mysqli_num_rows($result) > 0 ) {
		echo "<script>
				alert('Username sudah terdaftar!');
			  </script>";
		return false;
	}
	
	// Pengecekan
	if( $password != $password2 ) {
		echo "<script>
				alert('Konfirmasi password tidak sesuai!');
			  </script>";
		return false;
	}
	
	// enkripsi password 
		$password = password_hash($password, PASSWORD_DEFAULT);	
	
	// tambahkan user baru ke database
		mysqli_query($conn, "INSERT INTO user VALUES('', '$username', '$password')");
	
		return mysqli_affected_rows($conn);
}

?>
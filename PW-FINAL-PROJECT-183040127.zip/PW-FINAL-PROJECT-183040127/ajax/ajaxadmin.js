// Take the required elements
var keyword	= document.getElementById('keyword');
var cari 	= document.getElementById('cari');
var box		= document.getElementById('box');

// Add an event when the keyword is written
keyword.addEventListener('keyup', function() {

	// Create an Ajax
	var ajax = new XMLHttpRequest();

	// Check Ajax readiness
	ajax.onreadystatechange = function() {
		if(ajax.readyState == 4 && ajax.status == 200) {
			box.innerHTML = ajax.responseText;
		}
	}

	// Ajax Execution
	ajax.open('GET', 'halaman_ajax/halaman_admin_ajax.php?keyword=' + keyword.value, true);
	ajax.send();

});
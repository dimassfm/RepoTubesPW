<?php 
session_start();
if (isset($_SESSION['user'])) {
	header("Location: login_admin.php");
	exit;
}

require 'functions.php';

if( isset($_POST["register"])) {
	
	if ( registrasi($_POST) > 0 ) {
		print "<script>
					alert('User baru berhasil ditambahkan');
					document.location.href = 'login_admin.php';
   			  </script>";
	} else {
		print mysqli_error($conn);
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Registrasi</title>
<style type="text/css">
	body {
		font-family: arial;
		font-size: 14px;
		background-color: #222;
	}

	#utama {
		width: 300px;
		margin: 0 auto;
		margin-top: 12%;
	}

	#judul {
		padding: 15px;
		text-align: center;
		color: #fff;
		font-size: 20px;
		background-color: #339966;
		border-top-right-radius: 10px;
		border-top-left-radius: 10px; 
		border-bottom: 3px solid #336666;
	}

	#inputan {
		background-color: #eaeaec;
		padding: 20px;
		border-bottom-right-radius: 10px;
		border-bottom-left-radius: 10px; 
	}

	input {
		padding: 10px;
		border: 0;
	}

	.lg {
		width: 240px;
	}

	.btn {
		background-color: #339966;
		border-radius: 10px;
		color: #fff;
		height: 50px;
		width: 90px;
	}

	.btn:hover {
		background-color: #336666;
		cursor: pointer;
	}
</style>
</head>
<body>
	<div id="utama">
		<div id="judul">
			Registrasi
		</div>

	<?php if( isset($nValid) ) : ?>
		<p style="color: red; font-style: italic;">Username / Password salah</p>
	<?php endif; ?>

		<div id="inputan">
			<form action="" method="post">
				<div>
					<input type="text" name="username" placeholder="Username" class="lg">
				</div>
				<div style="margin-top: 10px;">
					<input type="password" name="password" id="password" placeholder="Password" class="lg">
				</div>
				<div style="margin-top: 10px;">
					<input type="password" name="password2" placeholder="Password2" id="password2" placeholder="Confirm Password" class="lg">
				</div>
				<div style="margin-top: 10px;">
					<button type="submit" name="register" class="btn">Sign Up</button>
				</div>
			</form>
		</div>
	</div>
</body>
</html>
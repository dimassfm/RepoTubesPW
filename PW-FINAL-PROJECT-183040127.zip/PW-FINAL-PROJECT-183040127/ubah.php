<?php
session_start();
if (!isset($_SESSION['user'])) {
	header("Location: login_admin.php");
	exit;
}
//Connet To Databases
require 'functions.php';
$genre = query("SELECT * FROM Genre ");

//Ambil data dari ULR

$Id = $_GET["id"];
//Query berdasarkan ID


$film = query("SELECT * FROM daftar_film WHERE daftar_film.Id = $Id")[0];

//Tombol Submit mengecek sudah di tekan atau belum
if( isset($_POST["ubah"]) ) {
//Pengecekan Berhasil Apa gagal di ubah
	if( ubah($_POST) > 0 ) {
		echo "
			<script>
				alert('Data Berhasil Diubah!');
				document.Location.href = 'halaman_admin.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('Data Gagal Diubah!'); 
				document.Location.href = 'halaman_admin.php';
			</script>
		";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Ubah Daftar Film</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<h2 class="text-center mb-5">Ubah Daftar Film</h2>

		<div class="kotak_ubah">
    		<h4 class="tulisan text-center">Silakan Ubah Data</h4><br>
		<form method="post" action="" enctype="multipart/form-data">
			<input type="hidden" name="Id" value="<?= $film["Id"]; ?>">
			<input type="hidden" name="GambarLama" value="<?= $film["Gambar"]; ?>">
			
			
				<div class="form-group">
					<label for="Masukkan Judul Film">Masukkan Judul Film : </label> 
					<input type="text" name="Judul" class="form-control form-control-sm" required  value="<?= $film['Judul']; ?>">
				</div>

				<div class="form-group">
				<select class="form-control form-control-m selectpicker" data-style="btn-white" data-live-search="true" data-size="5" name="Genre" required>
					<option value="">Masukkan Genre...</option>
					<?php foreach ($genre as $g) { ?>
					<option value="<?= $g['Id'] ?>"><?= $g['Genre'] ?></option>					
					<?php  } ?>
				</select>
			</div>

				<div class="form-group">
					<label for="Masukkan Sutradara">Masukkan Sutradara :</label>	 	 
					<input type="text" name="Sutradara" class="form-control form-control-sm" required value="<?= $film["Sutradara"]; ?>">
				</div>
				
				<div class="form-group">
					<label for="Masukkan Produser">Masukkan Produser :</label>
					<input type="text" name="Produser" class="form-control form-control-sm" required value="<?= $film["Produser"]; ?>">
				</div>
				
				<div class="form-group">
				<label for="Masukkan Sinopsis">Masukkan Sinopsis :</label>
				<input type="text" name="Sinopsis" class="form-control form-control-sm" required value="<?= $film['Sinopsis']; ?>">
				</div>	
				
				<div>
					<label for="Masukkan Gambar">Masukkan Gambar :</label>		 
					<input type="file" name="Gambar" id="Gambar" required>
				</div>

				<br>
				<br>
					<button type="submit" name="ubah" class="btn btn-primary">Ubah Data Film</button>
					<button type="button" onclick="window.location.href = 'halaman_admin.php';" class="btn btn-primary">Kembali</button>
			</form>
		</div>
	
	
	
	
</body>
</html>